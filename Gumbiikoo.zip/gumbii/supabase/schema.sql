-- GUMBII database setup (v2). Paste into Supabase > SQL Editor > Run.
-- Safe to re-run: if you already ran v1, just run this whole file again.

-- ---------- profiles (one row per registered member) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text default '',
  avatar_url text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz default now()
);
alter table public.profiles add column if not exists email text;
alter table public.profiles add column if not exists avatar_url text;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id, new.email,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    case when lower(new.email) = 'obsasenbeto9@gmail.com' then 'admin' else 'user' end
  )
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Backfill: members who registered before this version
insert into public.profiles (id, email, full_name)
select u.id, u.email, coalesce(u.raw_user_meta_data->>'full_name', '') from auth.users u
on conflict (id) do nothing;
update public.profiles p set email = u.email from auth.users u
  where u.id = p.id and (p.email is null or p.email = '');
-- The owner account is always admin
update public.profiles set role = 'admin' where lower(email) = 'obsasenbeto9@gmail.com';

create or replace function public.is_admin()
returns boolean language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- ---------- catalogues ----------
create table if not exists public.catalogues (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('video','article','image','app')),
  title text not null,
  description text default '',
  body text default '',
  file_url text default '',
  thumbnail_url text default '',
  external_url text default '',
  published boolean not null default true,
  created_at timestamptz default now()
);
alter table public.catalogues add column if not exists author_id uuid references auth.users(id) on delete set null default auth.uid();
alter table public.catalogues add column if not exists author_name text default '';

-- ---------- developer_profile (single row) ----------
create table if not exists public.developer_profile (
  id int primary key default 1 check (id = 1),
  name text default '',
  title text default '',
  bio text default '',
  expertise text default '',
  email text default '',
  phone text default '',
  telebirr_account text default '',
  cbe_account text default '',
  updated_at timestamptz default now()
);
insert into public.developer_profile (id, name, title, bio, expertise, email, phone, telebirr_account, cbe_account)
values (1, 'Obsa Temesgen Senbeto', 'Creator & Lead Developer',
        'Creator and lead developer of GUMBII.', 'Web development, React / Next.js, Supabase',
        'obsasenbeto9@gmail.com', '+251910349243', '+251910349243', '1000308029569')
on conflict (id) do nothing;

-- ---------- social_handles ----------
create table if not exists public.social_handles (
  id uuid primary key default gen_random_uuid(),
  platform text not null unique check (platform in ('telegram','tiktok','instagram','youtube')),
  username text not null default ''
);
insert into public.social_handles (platform, username) values
  ('telegram',''),('tiktok',''),('instagram',''),('youtube','')
on conflict (platform) do nothing;

-- ---------- Row Level Security ----------
alter table public.profiles enable row level security;
alter table public.catalogues enable row level security;
alter table public.developer_profile enable row level security;
alter table public.social_handles enable row level security;

-- profiles
drop policy if exists "profiles read own or admin" on public.profiles;
drop policy if exists "profiles update own (no role change)" on public.profiles;
drop policy if exists "profiles admin update" on public.profiles;
drop policy if exists "profiles insert own" on public.profiles;
create policy "profiles read own or admin" on public.profiles for select
  using (id = auth.uid() or public.is_admin());
create policy "profiles insert own" on public.profiles for insert
  with check (id = auth.uid() and role = 'user');
create policy "profiles update own (no role change)" on public.profiles for update
  using (id = auth.uid())
  with check (
    id = auth.uid()
    and role = (select p.role from public.profiles p where p.id = auth.uid())
    and email is not distinct from (select p.email from public.profiles p where p.id = auth.uid())
  );
create policy "profiles admin update" on public.profiles for update
  using (public.is_admin()) with check (public.is_admin());

-- catalogues: everyone reads published; members can submit (hidden until admin approves)
drop policy if exists "catalogues public read published" on public.catalogues;
drop policy if exists "catalogues admin insert" on public.catalogues;
drop policy if exists "catalogues admin update" on public.catalogues;
drop policy if exists "catalogues admin delete" on public.catalogues;
drop policy if exists "catalogues read" on public.catalogues;
drop policy if exists "catalogues insert" on public.catalogues;
drop policy if exists "catalogues update" on public.catalogues;
drop policy if exists "catalogues delete" on public.catalogues;
create policy "catalogues read" on public.catalogues for select
  using (published or public.is_admin() or author_id = auth.uid());
create policy "catalogues insert" on public.catalogues for insert
  with check (public.is_admin() or (auth.uid() is not null and author_id = auth.uid() and published = false));
create policy "catalogues update" on public.catalogues for update
  using (public.is_admin() or (author_id = auth.uid() and published = false))
  with check (public.is_admin() or (author_id = auth.uid() and published = false));
create policy "catalogues delete" on public.catalogues for delete
  using (public.is_admin() or author_id = auth.uid());

-- developer_profile
drop policy if exists "developer public read" on public.developer_profile;
drop policy if exists "developer admin insert" on public.developer_profile;
drop policy if exists "developer admin update" on public.developer_profile;
create policy "developer public read" on public.developer_profile for select using (true);
create policy "developer admin insert" on public.developer_profile for insert with check (public.is_admin());
create policy "developer admin update" on public.developer_profile for update using (public.is_admin());

-- social_handles
drop policy if exists "social public read" on public.social_handles;
drop policy if exists "social admin insert" on public.social_handles;
drop policy if exists "social admin update" on public.social_handles;
drop policy if exists "social admin delete" on public.social_handles;
create policy "social public read" on public.social_handles for select using (true);
create policy "social admin insert" on public.social_handles for insert with check (public.is_admin());
create policy "social admin update" on public.social_handles for update using (public.is_admin());
create policy "social admin delete" on public.social_handles for delete using (public.is_admin());

-- ---------- Storage ----------
-- media:   videos / pictures / apps. Path = <type>/<user id>/<file>
-- avatars: profile pictures.        Path = <user id>/<file>
insert into storage.buckets (id, name, public) values ('media','media',true), ('avatars','avatars',true)
on conflict (id) do nothing;

drop policy if exists "media public read" on storage.objects;
drop policy if exists "media admin insert" on storage.objects;
drop policy if exists "media admin update" on storage.objects;
drop policy if exists "media admin delete" on storage.objects;
drop policy if exists "media member insert" on storage.objects;
drop policy if exists "media member delete" on storage.objects;
drop policy if exists "avatar member insert" on storage.objects;
drop policy if exists "avatar member update" on storage.objects;
drop policy if exists "avatar member delete" on storage.objects;

create policy "media public read" on storage.objects for select
  using (bucket_id in ('media','avatars'));
create policy "media member insert" on storage.objects for insert
  with check (bucket_id = 'media' and auth.uid() is not null
    and (public.is_admin() or (storage.foldername(name))[2] = auth.uid()::text));
create policy "media admin update" on storage.objects for update
  using (bucket_id = 'media' and public.is_admin());
create policy "media member delete" on storage.objects for delete
  using (bucket_id = 'media' and (public.is_admin() or (storage.foldername(name))[2] = auth.uid()::text));

create policy "avatar member insert" on storage.objects for insert
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatar member update" on storage.objects for update
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatar member delete" on storage.objects for delete
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
