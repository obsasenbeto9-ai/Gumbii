export default function Avatar({ url, name, size = 36 }) {
  const initial = (name || '?').trim().charAt(0).toUpperCase();
  if (url) {
    return <img className="avatar" src={url} alt={name || 'avatar'} style={{ width: size, height: size }} />;
  }
  return (
    <span className="avatar ph" style={{ width: size, height: size, fontSize: size * 0.45 }}>
      {initial}
    </span>
  );
}
