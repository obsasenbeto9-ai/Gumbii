'use client';
import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';

const Ctx = createContext({ user: null, profile: null, loading: true, signOut: async () => {}, refresh: async () => {} });
export const useAuth = () => useContext(Ctx);

export default function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (u) => {
    if (!u) { setProfile(null); return; }
    let { data } = await supabase.from('profiles').select('*').eq('id', u.id).maybeSingle();
    if (!data) {
      // Member registered before the profile trigger existed: create their profile now.
      await supabase.from('profiles').insert({
        id: u.id, email: u.email, full_name: u.user_metadata?.full_name || '',
      });
      ({ data } = await supabase.from('profiles').select('*').eq('id', u.id).maybeSingle());
    }
    setProfile(data || null);
  }, []);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!active) return;
      const u = data.session?.user ?? null;
      setUser(u);
      await loadProfile(u);
      if (active) setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      const u = session?.user ?? null;
      setUser(u);
      setTimeout(() => loadProfile(u), 0);
    });
    return () => { active = false; sub.subscription.unsubscribe(); };
  }, [loadProfile]);

  const signOut = async () => { await supabase.auth.signOut(); };
  const refresh = () => loadProfile(user);

  return <Ctx.Provider value={{ user, profile, loading, signOut, refresh }}>{children}</Ctx.Provider>;
}
