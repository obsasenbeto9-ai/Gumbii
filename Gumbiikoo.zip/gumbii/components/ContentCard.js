import Link from 'next/link';
import { TYPE_META } from '@/lib/social';

export default function ContentCard({ item }) {
  const meta = TYPE_META[item.type];
  const thumb = item.thumbnail_url || (item.type === 'image' ? item.file_url : '');
  return (
    <Link href={`/content/${item.id}`} className="card item">
      <div className="thumb">
        {thumb ? <img src={thumb} alt={item.title} loading="lazy" /> : <span>{meta?.singular}</span>}
      </div>
      <div className="meta">
        <span className="tag">{meta?.singular}</span>
        <h3>{item.title}</h3>
        {item.description && <p>{item.description.slice(0, 110)}</p>}
      </div>
    </Link>
  );
}
