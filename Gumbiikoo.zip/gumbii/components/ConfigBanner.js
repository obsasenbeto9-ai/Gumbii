import { isConfigured } from '@/lib/supabase';

export default function ConfigBanner() {
  if (isConfigured) return null;
  return (
    <div className="banner">
      Supabase is not connected yet. Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
      (in .env.local, or in Vercel → Settings → Environment Variables) and redeploy.
    </div>
  );
}
