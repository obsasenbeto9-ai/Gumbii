'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/components/AuthProvider';
import Avatar from '@/components/Avatar';

const links = [
  ['/', 'Home'],
  ['/catalogue/videos', 'Videos'],
  ['/catalogue/articles', 'Articles'],
  ['/catalogue/images', 'Images'],
  ['/catalogue/apps', 'Apps'],
  ['/developer', 'Developer'],
];

export default function Header() {
  const path = usePathname();
  const { user, profile, signOut } = useAuth();
  return (
    <header className="header">
      <div className="container nav">
        <Link href="/" className="logo">GUMBII</Link>
        <nav className="links">
          {links.map(([href, label]) => (
            <Link key={href} href={href} className={path === href ? 'active' : ''}>{label}</Link>
          ))}
        </nav>
        <div className="links">
          {user && <Link href="/upload" className="btn small primary">+ Upload</Link>}
          {profile?.role === 'admin' && <Link href="/admin">Admin</Link>}
          {user ? (
            <>
              <Link href="/account" title="My account">
                <Avatar url={profile?.avatar_url} name={profile?.full_name || user.email} size={30} />
              </Link>
              <button className="btn small" onClick={signOut}>Log out</button>
            </>
          ) : (
            <>
              <Link href="/login">Log in</Link>
              <Link href="/register" className="btn small primary">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
