'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { uploadFile } from '@/lib/upload';
import Avatar from '@/components/Avatar';

export default function Account() {
  const { user, profile, loading, refresh } = useAuth();
  const [name, setName] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [pw, setPw] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { setName(profile?.full_name || ''); }, [profile]);

  if (loading) return <p>Loading…</p>;
  if (!user) return <p>Please <Link href="/login" style={{ color: 'var(--accent)' }}>log in</Link> to see your account.</p>;

  const ok = (m) => { setErr(''); setMsg(m); };
  const fail = (m) => { setMsg(''); setErr(m); };

  async function saveName(e) {
    e.preventDefault();
    const { error } = await supabase.from('profiles').update({ full_name: name }).eq('id', user.id);
    if (error) return fail(error.message);
    ok('Profile saved.'); refresh();
  }

  async function changeAvatar(file) {
    if (!file) return;
    if (!file.type.startsWith('image/')) return fail('Please choose an image file.');
    setBusy(true);
    try {
      const url = await uploadFile('avatars', [user.id], file);
      const { error } = await supabase.from('profiles').update({ avatar_url: url }).eq('id', user.id);
      if (error) throw error;
      ok('Profile picture updated.'); refresh();
    } catch (e) { fail(e.message); }
    setBusy(false);
  }

  async function changePw(e) {
    e.preventDefault();
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) return fail(error.message);
    ok('Password updated.'); setPw('');
  }

  return (
    <div className="form wide">
      <h1>My account</h1>
      <div className="card">
        <div className="row" style={{ marginBottom: 12 }}>
          <Avatar url={profile?.avatar_url} name={profile?.full_name || user.email} size={84} />
          <label className="btn small upl">
            {busy ? 'Uploading…' : 'Change profile picture'}
            <input type="file" accept="image/*" hidden disabled={busy} onChange={(e) => changeAvatar(e.target.files?.[0])} />
          </label>
        </div>
        <p>Email: <strong style={{ color: 'var(--text)' }}>{user.email}</strong></p>
        <p>Role: <strong style={{ color: 'var(--text)' }}>{profile?.role || 'user'}</strong></p>
        <form onSubmit={saveName}>
          <label>Full name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} />
          <p><button className="btn primary">Save profile</button></p>
        </form>
        <form onSubmit={changePw}>
          <label>New password</label>
          <input type="password" minLength={6} value={pw} onChange={(e) => setPw(e.target.value)} />
          <p><button className="btn" disabled={pw.length < 6}>Change password</button></p>
        </form>
        {msg && <p className="msg">{msg}</p>}
        {err && <p className="msg err">{err}</p>}
        <p><Link href="/upload" className="btn">Go to my uploads</Link></p>
      </div>
    </div>
  );
}
