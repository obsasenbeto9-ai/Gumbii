'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { PATH_TO_TYPE, TYPE_META } from '@/lib/social';
import ContentCard from '@/components/ContentCard';

export default function Catalogue() {
  const { type: slug } = useParams();
  const type = PATH_TO_TYPE[slug];
  const [items, setItems] = useState([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!type) return;
    setLoading(true);
    let query = supabase.from('catalogues').select('*').eq('type', type).eq('published', true)
      .order('created_at', { ascending: false });
    if (q.trim()) query = query.ilike('title', `%${q.trim().replace(/[%,]/g, '')}%`);
    const t = setTimeout(() => {
      query.then(({ data }) => { setItems(data || []); setLoading(false); });
    }, 250);
    return () => clearTimeout(t);
  }, [type, q]);

  if (!type) return <p>Catalogue not found.</p>;
  return (
    <>
      <h1>{TYPE_META[type].label}</h1>
      <input className="search" placeholder={`Search ${TYPE_META[type].label.toLowerCase()}…`} value={q} onChange={(e) => setQ(e.target.value)} />
      {loading ? <p>Loading…</p> : items.length === 0 ? <p>Nothing here yet.</p> : (
        <div className="grid">{items.map((i) => <ContentCard key={i.id} item={i} />)}</div>
      )}
    </>
  );
}
