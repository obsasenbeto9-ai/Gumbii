'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setErr('');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) setErr(error.message); else router.push('/account');
  }

  return (
    <form className="form card" onSubmit={submit}>
      <h1>Log in</h1>
      <label>Email</label>
      <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
      <label>Password</label>
      <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
      {err && <p className="msg err">{err}</p>}
      <p><button className="btn primary" disabled={busy}>{busy ? 'Please wait…' : 'Log in'}</button></p>
      <p>No account? <Link href="/register" style={{ color: 'var(--accent)' }}>Sign up</Link></p>
    </form>
  );
}
