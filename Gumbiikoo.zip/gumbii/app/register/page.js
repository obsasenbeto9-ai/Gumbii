'use client';
import { useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setErr(''); setMsg('');
    const { data, error } = await supabase.auth.signUp({
      email, password, options: { data: { full_name: name } },
    });
    setBusy(false);
    if (error) return setErr(error.message);
    setMsg(data.session ? 'Account created. You are logged in.' : 'Account created. Check your email to confirm, then log in.');
  }

  return (
    <form className="form card" onSubmit={submit}>
      <h1>Create account</h1>
      <label>Full name</label>
      <input required value={name} onChange={(e) => setName(e.target.value)} />
      <label>Email</label>
      <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
      <label>Password (min 6 characters)</label>
      <input type="password" minLength={6} required value={password} onChange={(e) => setPassword(e.target.value)} />
      {err && <p className="msg err">{err}</p>}
      {msg && <p className="msg">{msg}</p>}
      <p><button className="btn primary" disabled={busy}>{busy ? 'Please wait…' : 'Sign up'}</button></p>
      <p>Already registered? <Link href="/login" style={{ color: 'var(--accent)' }}>Log in</Link></p>
    </form>
  );
}
