'use client';
import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { PLATFORMS, cleanHandle } from '@/lib/social';
import { uploadFile } from '@/lib/upload';
import Avatar from '@/components/Avatar';

const TYPES = ['video', 'article', 'image', 'app'];

export default function Admin() {
  const { profile, loading } = useAuth();
  const [tab, setTab] = useState('content');
  if (loading) return <p>Loading…</p>;
  if (profile?.role !== 'admin') {
    return <p className="card">Admins only. Log in with the owner account (obsasenbeto9@gmail.com). If you registered it and still see this, re-run supabase/schema.sql.</p>;
  }
  return (
    <div>
      <h1>Admin dashboard</h1>
      <div className="tabs">
        {['content', 'members', 'developer', 'social'].map((t) => (
          <button key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t}</button>
        ))}
      </div>
      {tab === 'content' && <ContentTab />}
      {tab === 'members' && <MembersTab />}
      {tab === 'developer' && <DeveloperTab />}
      {tab === 'social' && <SocialTab />}
    </div>
  );
}

function ContentTab() {
  const { user, profile } = useAuth();
  const empty = { type: 'video', title: '', description: '', body: '', file_url: '', thumbnail_url: '', external_url: '', published: true };
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(empty);
  const [id, setId] = useState(null);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [k, setK] = useState(0);

  const load = useCallback(async () => {
    const { data } = await supabase.from('catalogues').select('*').order('created_at', { ascending: false });
    const list = data || [];
    list.sort((a, b) => Number(a.published) - Number(b.published)); // waiting items first
    setItems(list);
  }, []);
  useEffect(() => { load(); }, [load]);

  const set = (key, v) => setForm((f) => ({ ...f, [key]: v }));
  const waiting = items.filter((i) => !i.published).length;

  async function pick(file, key) {
    if (!file) return;
    setBusy(true); setErr(''); setMsg('Uploading…');
    try {
      const url = await uploadFile('media', [form.type, user.id], file);
      set(key, url); setMsg('Upload complete ✓');
    } catch (e) { setErr(e.message); setMsg(''); }
    setBusy(false);
  }

  async function save(e) {
    e.preventDefault();
    setErr(''); setMsg('');
    const payload = id ? form : { ...form, author_id: user.id, author_name: profile?.full_name || user.email };
    const q = id ? supabase.from('catalogues').update(payload).eq('id', id) : supabase.from('catalogues').insert(payload);
    const { error } = await q;
    if (error) return setErr(error.message);
    setMsg('Saved ✓'); setForm(empty); setId(null); setK((n) => n + 1); load();
  }

  function edit(item) {
    const { id: _id, created_at, ...rest } = item;
    setForm({ ...empty, ...rest });
    setId(item.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function del(itemId) {
    if (!confirm('Delete this item permanently?')) return;
    const { error } = await supabase.from('catalogues').delete().eq('id', itemId);
    if (error) setErr(error.message); else { setMsg('Deleted.'); load(); }
  }

  async function togglePublish(item) {
    const { error } = await supabase.from('catalogues').update({ published: !item.published }).eq('id', item.id);
    if (error) setErr(error.message); else load();
  }

  return (
    <>
      <form className="card" onSubmit={save}>
        <h2 style={{ marginTop: 0 }}>{id ? 'Edit item' : 'Add new item'}</h2>
        <label>Type</label>
        <select value={form.type} onChange={(e) => set('type', e.target.value)}>
          {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <label>Title</label>
        <input required value={form.title} onChange={(e) => set('title', e.target.value)} />
        <label>Description</label>
        <textarea rows={2} value={form.description} onChange={(e) => set('description', e.target.value)} />
        {form.type === 'article' && (
          <>
            <label>Article text</label>
            <textarea rows={10} value={form.body} onChange={(e) => set('body', e.target.value)} />
          </>
        )}
        {form.type !== 'article' && (
          <>
            <label>Upload file ({form.type === 'app' ? 'apk / zip / exe' : form.type})</label>
            <input key={`f${k}`} type="file" onChange={(e) => pick(e.target.files?.[0], 'file_url')} />
            <label>…or file / external URL (YouTube links work for videos)</label>
            <input value={form.file_url || form.external_url} onChange={(e) => { set('file_url', ''); set('external_url', e.target.value); }} placeholder="https://" />
            {form.file_url && <p style={{ fontSize: '.8rem' }}>Uploaded: {form.file_url}</p>}
          </>
        )}
        <label>Cover picture (upload)</label>
        <input key={`t${k}`} type="file" accept="image/*" onChange={(e) => pick(e.target.files?.[0], 'thumbnail_url')} />
        {form.thumbnail_url && <p style={{ fontSize: '.8rem' }}>{form.thumbnail_url}</p>}
        <label><input type="checkbox" style={{ width: 'auto', marginRight: 8 }} checked={form.published} onChange={(e) => set('published', e.target.checked)} />Published (visible to everyone)</label>
        <p className="row">
          <button className="btn primary" disabled={busy}>{id ? 'Update' : 'Add'}</button>
          {id && <button type="button" className="btn" onClick={() => { setForm(empty); setId(null); }}>Cancel</button>}
        </p>
        {err && <p className="msg err">{err}</p>}
        {msg && <p className="msg">{msg}</p>}
      </form>

      <h2>All content ({items.length}){waiting > 0 && <span className="badge wait" style={{ marginLeft: 10 }}>{waiting} waiting for approval</span>}</h2>
      <table className="table">
        <thead><tr><th>Title</th><th>Type</th><th>By</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.id}>
              <td>{i.title}</td>
              <td>{i.type}</td>
              <td>{i.author_name || '—'}</td>
              <td><span className={`badge ${i.published ? 'live' : 'wait'}`}>{i.published ? 'Live' : 'Hidden'}</span></td>
              <td className="row">
                <button className="btn small" onClick={() => togglePublish(i)}>{i.published ? 'Hide' : 'Approve'}</button>
                <button className="btn small" onClick={() => edit(i)}>Edit</button>
                <button className="btn small danger" onClick={() => del(i.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

function MembersTab() {
  const [users, setUsers] = useState(null);
  const [q, setQ] = useState('');
  const [msg, setMsg] = useState('');
  const load = useCallback(async () => {
    const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (error) setMsg(error.message);
    setUsers(data || []);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function setRole(id, role) {
    const { error } = await supabase.from('profiles').update({ role }).eq('id', id);
    setMsg(error ? error.message : 'Role updated.');
    load();
  }

  function exportCsv() {
    const rows = [['name', 'email', 'role', 'joined'], ...users.map((u) => [u.full_name, u.email, u.role, u.created_at])];
    const csv = rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'gumbii-members.csv';
    a.click();
  }

  if (!users) return <p>Loading…</p>;
  const shown = users.filter((u) => `${u.full_name} ${u.email}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <div className="row" style={{ justifyContent: 'space-between', marginBottom: 12 }}>
        <h2 style={{ margin: 0 }}>Registered members ({users.length})</h2>
        <button className="btn small" onClick={exportCsv}>Download list (CSV)</button>
      </div>
      <input className="search" placeholder="Search by name or email…" value={q} onChange={(e) => setQ(e.target.value)} />
      <table className="table">
        <thead><tr><th></th><th>Name</th><th>Email</th><th>Joined</th><th>Role</th><th></th></tr></thead>
        <tbody>
          {shown.map((u) => (
            <tr key={u.id}>
              <td><Avatar url={u.avatar_url} name={u.full_name || u.email} size={30} /></td>
              <td>{u.full_name || '(no name)'}</td>
              <td>{u.email}</td>
              <td>{new Date(u.created_at).toLocaleDateString()}</td>
              <td>{u.role}</td>
              <td>
                {u.role === 'admin'
                  ? <button className="btn small" onClick={() => setRole(u.id, 'user')}>Make member</button>
                  : <button className="btn small" onClick={() => setRole(u.id, 'admin')}>Make admin</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {msg && <p className="msg">{msg}</p>}
    </>
  );
}

function DeveloperTab() {
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState('');
  useEffect(() => {
    supabase.from('developer_profile').select('*').eq('id', 1).maybeSingle()
      .then(({ data }) => setF(data || { id: 1, name: '', title: '', bio: '', expertise: '', email: '', phone: '', telebirr_account: '', cbe_account: '' }));
  }, []);
  if (!f) return <p>Loading…</p>;
  const set = (key, v) => setF((x) => ({ ...x, [key]: v }));
  async function save(e) {
    e.preventDefault();
    const { error } = await supabase.from('developer_profile').upsert({ ...f, id: 1, updated_at: new Date().toISOString() });
    setMsg(error ? error.message : 'Saved. The Developer page is updated.');
  }
  const field = (key, label, area) => (
    <>
      <label>{label}</label>
      {area
        ? <textarea rows={4} value={f[key] || ''} onChange={(e) => set(key, e.target.value)} />
        : <input value={f[key] || ''} onChange={(e) => set(key, e.target.value)} />}
    </>
  );
  return (
    <form className="card form wide" onSubmit={save}>
      {field('name', 'Name')}
      {field('title', 'Title')}
      {field('bio', 'Bio', true)}
      {field('expertise', 'Expertise')}
      {field('email', 'Contact email')}
      {field('phone', 'Phone')}
      {field('telebirr_account', 'Telebirr account')}
      {field('cbe_account', 'CBE account number')}
      <p><button className="btn primary">Save</button></p>
      {msg && <p className="msg">{msg}</p>}
    </form>
  );
}

function SocialTab() {
  const [vals, setVals] = useState({});
  const [msg, setMsg] = useState('');
  useEffect(() => {
    supabase.from('social_handles').select('*').then(({ data }) => {
      const m = {};
      (data || []).forEach((h) => { m[h.platform] = h.username; });
      setVals(m);
    });
  }, []);
  async function save(e) {
    e.preventDefault();
    const rows = Object.keys(PLATFORMS).map((p) => ({ platform: p, username: cleanHandle(vals[p]) }));
    const { error } = await supabase.from('social_handles').upsert(rows, { onConflict: 'platform' });
    setMsg(error ? error.message : 'Saved.');
  }
  return (
    <form className="card form" onSubmit={save}>
      <p>Enter the username only. Links are built automatically.</p>
      {Object.entries(PLATFORMS).map(([key, p]) => (
        <div key={key}>
          <label>{p.label} username</label>
          <input value={vals[key] || ''} onChange={(e) => setVals((v) => ({ ...v, [key]: e.target.value }))} placeholder="username" />
          {cleanHandle(vals[key]) && <span style={{ fontSize: '.8rem', color: 'var(--muted)' }}>{p.url(cleanHandle(vals[key]))}</span>}
        </div>
      ))}
      <p><button className="btn primary">Save handles</button></p>
      {msg && <p className="msg">{msg}</p>}
    </form>
  );
}
