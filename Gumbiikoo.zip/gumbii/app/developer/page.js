'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { PLATFORMS } from '@/lib/social';
import CopyButton from '@/components/CopyButton';

const FALLBACK = {
  name: 'Obsa Temesgen Senbeto',
  title: 'Creator & Lead Developer',
  bio: '',
  expertise: '',
  email: 'obsasenbeto9@gmail.com',
  phone: '+251910349243',
  telebirr_account: '+251910349243',
  cbe_account: '1000308029569',
};

export default function Developer() {
  const [dev, setDev] = useState(FALLBACK);
  const [handles, setHandles] = useState([]);

  useEffect(() => {
    supabase.from('developer_profile').select('*').eq('id', 1).maybeSingle()
      .then(({ data }) => { if (data) setDev({ ...FALLBACK, ...Object.fromEntries(Object.entries(data).filter(([, v]) => v)) }); });
    supabase.from('social_handles').select('*')
      .then(({ data }) => setHandles((data || []).filter((h) => h.username && PLATFORMS[h.platform])));
  }, []);

  return (
    <>
      <h1>{dev.name}</h1>
      <p style={{ color: 'var(--accent)', marginTop: -6 }}>{dev.title}</p>
      {dev.bio && <p style={{ maxWidth: 700 }}>{dev.bio}</p>}
      {dev.expertise && <p><strong style={{ color: 'var(--text)' }}>Expertise:</strong> {dev.expertise}</p>}

      <div className="two">
        <section className="card">
          <h2 style={{ marginTop: 0 }}>Contact</h2>
          {dev.email && <p>Email: <a href={`mailto:${dev.email}`} style={{ color: 'var(--accent)' }}>{dev.email}</a></p>}
          {dev.phone && <p>Phone: <a href={`tel:${dev.phone}`} style={{ color: 'var(--accent)' }}>{dev.phone}</a></p>}
          {handles.length > 0 && (
            <>
              <h3>Find me online</h3>
              <div className="pills">
                {handles.map((h) => (
                  <a key={h.id} className="btn small" href={PLATFORMS[h.platform].url(h.username)} target="_blank" rel="noopener noreferrer">
                    {PLATFORMS[h.platform].label}
                  </a>
                ))}
              </div>
            </>
          )}
        </section>

        <section className="card">
          <h2 style={{ marginTop: 0 }}>Support &amp; Contribute</h2>
          <p>If you enjoy GUMBII, you can support its development.</p>
          <div className="pay">
            <div><span>Telebirr</span><strong>{dev.telebirr_account}</strong></div>
            <CopyButton value={dev.telebirr_account} label="Copy Telebirr" />
          </div>
          <div className="pay">
            <div><span>Commercial Bank of Ethiopia (CBE)</span><strong>{dev.cbe_account}</strong></div>
            <CopyButton value={dev.cbe_account} label="Copy CBE" />
          </div>
          <p style={{ fontSize: '.85rem' }}>Account name: {dev.name}</p>
        </section>
      </div>
    </>
  );
}
