'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { TYPE_META } from '@/lib/social';
import ContentCard from '@/components/ContentCard';

export default function Home() {
  const [latest, setLatest] = useState([]);
  useEffect(() => {
    supabase.from('catalogues').select('*').eq('published', true)
      .order('created_at', { ascending: false }).limit(8)
      .then(({ data }) => setLatest(data || []));
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Welcome to GUMBII</h1>
        <p>Videos, articles, image galleries and downloadable apps — all in one organised place.</p>
        <div className="cats">
          {Object.values(TYPE_META).map((m) => (
            <Link key={m.path} href={`/catalogue/${m.path}`} className="card">{m.label}</Link>
          ))}
        </div>
      </section>
      <h2>Latest</h2>
      {latest.length === 0 ? <p>No content yet. Check back soon.</p> : (
        <div className="grid">{latest.map((i) => <ContentCard key={i.id} item={i} />)}</div>
      )}
    </>
  );
}
