import './globals.css';
import './extra.css';
import AuthProvider from '@/components/AuthProvider';
import Header from '@/components/Header';
import ConfigBanner from '@/components/ConfigBanner';

export const metadata = {
  title: 'GUMBII',
  description: 'Videos, articles, image galleries and downloadable apps by Obsa Temesgen Senbeto.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <ConfigBanner />
        <AuthProvider>
          <Header />
          <main className="container">{children}</main>
          <footer className="footer">© {new Date().getFullYear()} GUMBII · Built by Obsa Temesgen Senbeto</footer>
        </AuthProvider>
      </body>
    </html>
  );
}
