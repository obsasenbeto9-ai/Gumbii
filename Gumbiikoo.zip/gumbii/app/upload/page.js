'use client';
import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/components/AuthProvider';
import { uploadFile } from '@/lib/upload';

const KINDS = [
  ['video', 'Video'],
  ['image', 'Picture'],
  ['article', 'Post / Article'],
  ['app', 'App'],
];
const EMPTY = { type: 'video', title: '', description: '', body: '', file_url: '', thumbnail_url: '', external_url: '' };

export default function Upload() {
  const { user, profile, loading } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const [f, setF] = useState(EMPTY);
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [mine, setMine] = useState([]);
  const [k, setK] = useState(0);

  const load = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('catalogues')
      .select('id,title,type,published,created_at').eq('author_id', user.id)
      .order('created_at', { ascending: false });
    setMine(data || []);
  }, [user]);
  useEffect(() => { load(); }, [load]);

  if (loading) return <p>Loading…</p>;
  if (!user) return <p>Please <Link href="/login" style={{ color: 'var(--accent)' }}>log in</Link> or <Link href="/register" style={{ color: 'var(--accent)' }}>sign up</Link> to upload.</p>;

  const set = (key, v) => setF((x) => ({ ...x, [key]: v }));

  async function pick(file, key) {
    if (!file) return;
    setBusy(true); setErr(''); setMsg('Uploading… please wait, large files take a while.');
    try {
      const url = await uploadFile('media', [f.type, user.id], file);
      set(key, url);
      setMsg('File uploaded ✓');
    } catch (e) { setErr(e.message); setMsg(''); }
    setBusy(false);
  }

  async function submit(e) {
    e.preventDefault();
    setErr(''); setMsg('');
    if (f.type === 'article' && !f.body.trim()) return setErr('Please write your post text.');
    if (f.type !== 'article' && !f.file_url && !f.external_url) return setErr('Upload a file or paste a link first.');
    setBusy(true);
    const { error } = await supabase.from('catalogues').insert({
      ...f, published: isAdmin, author_id: user.id,
      author_name: profile?.full_name || user.email,
    });
    setBusy(false);
    if (error) return setErr(error.message);
    setMsg(isAdmin ? 'Published ✓' : 'Submitted ✓ It will appear on the site once the owner approves it.');
    setF(EMPTY); setK((n) => n + 1); load();
  }

  async function remove(id) {
    if (!confirm('Delete this upload?')) return;
    const { error } = await supabase.from('catalogues').delete().eq('id', id);
    if (error) setErr(error.message); else load();
  }

  const accept = f.type === 'video' ? 'video/*' : f.type === 'image' ? 'image/*' : undefined;

  return (
    <div className="wide">
      <h1>Upload</h1>
      <p>Share a video, picture, post or app. {isAdmin ? 'As owner, your uploads go live immediately.' : 'New uploads are reviewed by the owner before they appear.'}</p>
      <form className="card" onSubmit={submit}>
        <label>What are you uploading?</label>
        <select value={f.type} onChange={(e) => { set('type', e.target.value); set('file_url', ''); setK((n) => n + 1); }}>
          {KINDS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>

        <label>Title</label>
        <input required value={f.title} onChange={(e) => set('title', e.target.value)} />

        <label>Short description</label>
        <textarea rows={2} value={f.description} onChange={(e) => set('description', e.target.value)} />

        {f.type === 'article' ? (
          <>
            <label>Post text</label>
            <textarea rows={10} value={f.body} onChange={(e) => set('body', e.target.value)} />
            <label>Cover picture (optional)</label>
            <input key={`c${k}`} type="file" accept="image/*" onChange={(e) => pick(e.target.files?.[0], 'thumbnail_url')} />
          </>
        ) : (
          <>
            <label>Choose file</label>
            <input key={`f${k}`} type="file" accept={accept} onChange={(e) => pick(e.target.files?.[0], 'file_url')} />
            {f.file_url && f.type === 'image' && <img src={f.file_url} alt="preview" style={{ marginTop: 10, maxHeight: 180, borderRadius: 8 }} />}
            <label>…or paste a link{f.type === 'video' ? ' (YouTube works)' : ''}</label>
            <input value={f.external_url} onChange={(e) => set('external_url', e.target.value)} placeholder="https://" />
            {f.type !== 'image' && (
              <>
                <label>Cover picture (optional)</label>
                <input key={`t${k}`} type="file" accept="image/*" onChange={(e) => pick(e.target.files?.[0], 'thumbnail_url')} />
              </>
            )}
          </>
        )}

        {err && <p className="msg err">{err}</p>}
        {msg && <p className="msg">{msg}</p>}
        <p><button className="btn primary" disabled={busy}>{busy ? 'Please wait…' : isAdmin ? 'Publish' : 'Submit'}</button></p>
      </form>

      <h2>My uploads ({mine.length})</h2>
      {mine.length === 0 ? <p>Nothing yet.</p> : (
        <table className="table">
          <tbody>
            {mine.map((i) => (
              <tr key={i.id}>
                <td>{i.title}</td>
                <td>{i.type}</td>
                <td><span className={`badge ${i.published ? 'live' : 'wait'}`}>{i.published ? 'Live' : 'Waiting for approval'}</span></td>
                <td><button className="btn small danger" onClick={() => remove(i.id)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
