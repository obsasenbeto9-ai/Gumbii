'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { TYPE_META } from '@/lib/social';
import { youtubeEmbed } from '@/lib/upload';

export default function ContentDetail() {
  const { id } = useParams();
  const [item, setItem] = useState(null);
  const [state, setState] = useState('loading');

  useEffect(() => {
    supabase.from('catalogues').select('*').eq('id', id).maybeSingle().then(({ data }) => {
      setItem(data);
      setState(data ? 'ok' : 'missing');
    });
  }, [id]);

  if (state === 'loading') return <p>Loading…</p>;
  if (state === 'missing') return <p>This item could not be found.</p>;

  const src = item.file_url || item.external_url;
  const embed = youtubeEmbed(item.external_url);
  return (
    <article>
      <span className="tag">{TYPE_META[item.type]?.singular}</span>
      <h1>{item.title}</h1>
      {item.author_name && <p style={{ marginTop: -6 }}>Posted by {item.author_name}</p>}
      {item.description && <p>{item.description}</p>}

      {item.type === 'video' && item.file_url && (
        <video controls preload="metadata" poster={item.thumbnail_url || undefined} src={item.file_url} style={{ width: '100%', borderRadius: 12 }} />
      )}
      {item.type === 'video' && !item.file_url && embed && (
        <iframe className="iframe16" src={embed} title={item.title} allowFullScreen />
      )}
      {item.type === 'video' && !item.file_url && !embed && item.external_url && (
        <p><a className="btn primary" href={item.external_url} target="_blank" rel="noopener noreferrer">Watch video</a></p>
      )}
      {item.type === 'image' && src && <img src={src} alt={item.title} style={{ borderRadius: 12 }} />}
      {item.type === 'article' && (
        <>
          {item.thumbnail_url && <img src={item.thumbnail_url} alt="" style={{ borderRadius: 12, marginBottom: 16 }} />}
          <div className="article-body">{item.body}</div>
        </>
      )}
      {item.type === 'app' && (
        <div className="card" style={{ marginTop: 16 }}>
          {src ? <a className="btn primary" href={src} download target="_blank" rel="noopener noreferrer">Download</a> : <p>No file attached yet.</p>}
        </div>
      )}
    </article>
  );
}
