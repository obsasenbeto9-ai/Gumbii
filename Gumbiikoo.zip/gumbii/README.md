# GUMBII

Catalogue platform (videos, articles, images, downloadable apps) by Obsa Temesgen Senbeto.
Stack: Next.js 14 (App Router) · Supabase (Postgres, Auth, Storage) · GitHub → Vercel.

## What members and the owner can do

- **Anyone:** browse and search Videos, Articles, Images, Apps; see the Developer page (contact, social links, Telebirr / CBE copy buttons).
- **Registered members:** log in, set a profile picture and name (Account page), and upload videos, pictures, posts and apps (Upload page). Member uploads wait for the owner's approval.
- **Owner (admin):** the account registered with `obsasenbeto9@gmail.com` is made admin automatically. The Admin dashboard lets you approve/hide/edit/delete content, see every registered member (name, email, picture, join date) and download the list as CSV, and edit developer details and social usernames.

## Setup

### 1. Supabase
1. Create a project at supabase.com.
2. SQL Editor → paste `supabase/schema.sql` → Run. It is safe to run again later (for example after updating to a new version).
3. Project Settings → API: copy the Project URL and the `anon` public key.
4. Authentication → Providers → Email: turn off "Confirm email" if you want instant sign-up.

### 2. Run locally
```
cp .env.example .env.local     # fill in the two Supabase values
npm install
npm run dev
```
If the yellow "Supabase is not connected" bar shows at the top, the two environment variables are missing.

### 3. Become admin
Register on the site with `obsasenbeto9@gmail.com`. Register this account first, before sharing the site. It becomes admin automatically and an **Admin** link appears in the header. If you registered before installing this version, just re-run `schema.sql`.

### 4. GitHub + Vercel
```
git init && git add . && git commit -m "GUMBII"
git branch -M main
git remote add origin https://github.com/<you>/gumbii.git
git push -u origin main
```
In Vercel: Add New Project → import the repo → add env vars `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` → Deploy. Every push to `main` redeploys.

## Notes
- Only the `anon` key is used in the browser; all writes are protected by Row Level Security.
- Members can only add content as "hidden"; only an admin can publish. Role changes by normal users are blocked.
- Supabase free tier limits a single upload to 50 MB. For longer videos, paste a YouTube link instead; it plays embedded.
- Social handles take usernames only (Telegram, TikTok, Instagram, YouTube); links are built in `lib/social.js`.
